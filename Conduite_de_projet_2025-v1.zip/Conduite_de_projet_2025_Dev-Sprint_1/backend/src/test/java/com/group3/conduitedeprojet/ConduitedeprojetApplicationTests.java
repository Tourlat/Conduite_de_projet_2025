package com.group3.conduitedeprojet;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConduitedeprojetApplicationTests {

}
